﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using RobotOM;

namespace GeomFilterNamespace
{
    [System.Runtime.InteropServices.ComVisibleAttribute(true), System.Runtime.InteropServices.Guid("8BE3FAFE-089C-47CF-AA84-123D2E90D53E")]
    public class Class1 : IRobotAddIn
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        //[STAThread]
        
        private IRobotApplication iapp = null;
        public bool Connect(RobotApplication robot_app, int add_in_id, bool first_time)
        {
            iapp = robot_app;
            return true;
        }

        public bool Disconnect()
        {
            iapp = null;
            return true;
        }

        public void DoCommand(int cmd_id)
        {
            Form GeomFilter = new GeomFilter();
            GeomFilter.Show();
        }

        public double GetExpectedVersion()
        {
            return 0;
        }

        public int InstallCommands(RobotCmdList cmd_list)
        {
            cmd_list.New(1, "Geometry Filter"); // Text in Robot menu
            return cmd_list.Count;
        }
    }
}
